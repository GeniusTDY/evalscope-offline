import copy
from collections import OrderedDict
from dataclasses import asdict, dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Type, Union

from pydantic import BaseModel

from evalscope.api.metric.semantics import MetricSelector
from evalscope.constants import OutputType
from evalscope.metrics.semantics.identity import migrate_legacy_identity
from evalscope.utils import get_logger

logger = get_logger()

if TYPE_CHECKING:
    from evalscope.api.benchmark import DataAdapter
    from evalscope.api.benchmark.statistics import DataStatistics, SampleExample


@dataclass
class BenchmarkMeta:
    """Metadata for a benchmark, including dataset and model configurations."""

    name: str
    """ Unique name of the benchmark."""

    dataset_id: str
    """ Dataset id on modelscope or path to local dataset."""

    data_adapter: Optional[Type['DataAdapter']] = None
    """ Data adapter class for the benchmark."""

    output_types: List[str] = field(default_factory=lambda: [OutputType.GENERATION])
    """ List of output types supported by the benchmark."""

    subset_list: List[str] = field(default_factory=lambda: ['default'])
    """ List of subsets available for the benchmark."""

    default_subset: str = 'default'
    """ Default subset to use for the benchmark."""

    few_shot_num: int = 0
    """ Number of few-shot examples to use."""

    few_shot_random: bool = False
    """ Whether to use random few-shot examples."""

    train_split: Optional[str] = None
    """ Training split to use for the benchmark."""

    eval_split: Optional[str] = None
    """ Evaluation split to use for the benchmark."""

    prompt_template: Optional[str] = None
    """ Prompt template to use for the benchmark."""

    few_shot_prompt_template: Optional[str] = None
    """ Few-shot prompt template to use for the benchmark."""

    system_prompt: Optional[str] = None
    """ System prompt to use for the benchmark."""

    query_template: Optional[str] = None
    """ Query template to use for the benchmark."""

    pretty_name: Optional[str] = None
    """ Human-readable name for the benchmark."""

    description: Optional[str] = None
    """ Description of the benchmark."""

    # === Documentation & Reference Fields ===
    paper_url: Optional[str] = None
    """ URL to the original paper for this benchmark."""

    # === Data Statistics & Examples (computed lazily or predefined) ===
    data_statistics: Optional['DataStatistics'] = None
    """ Statistics about the dataset (sample counts, prompt lengths, etc.)."""

    sample_example: Optional['SampleExample'] = None
    """ A representative sample example for documentation."""

    tags: List[str] = field(default_factory=list)
    """ Tags associated with the benchmark."""

    filters: Optional[OrderedDict] = None
    """ Filters to apply to the dataset on model output."""

    metric_list: List[Union[str, Dict[str, Any]]] = field(default_factory=list)
    """ List of metrics to evaluate the benchmark."""

    aggregation: str = 'mean'
    """ Aggregation function for the metrics. Default is 'mean'. Can be 'mean', 'pass@<k>' or a custom function name."""

    primary_metric: Optional[Union[str, MetricSelector]] = None
    """Structured selector for the benchmark's primary report metric.

    This is the report-level authoritative declaration. Optional for single-metric benchmarks
    (the only scored identity is implicitly primary). If a report contains several scored
    identities, it must provide a selector that matches exactly one of them. Every other
    non-diagnostic metric is resolved as ``auxiliary``.
    """

    shuffle: bool = False
    """Whether to shuffle the dataset before evaluation."""

    shuffle_choices: bool = False
    """Whether to shuffle the choices in multiple-choice datasets."""

    force_redownload: bool = False
    """Whether to force redownload the dataset from remote source."""

    review_timeout: Optional[float] = None
    """ Timeout for review in seconds."""

    extra_params: Dict = field(default_factory=dict)
    """Additional parameters for the benchmark.
        The structure is:
        {
          "param": {
             "type": "int",
             "description": "...",
             "value": 10,
             "choices": [5, 10]        # optional for enum type checks
          },
          ...
        }
    """

    sandbox_config: Optional[Dict[str, Any]] = field(default_factory=dict)
    """Configuration for sandboxed code execution environments. """

    max_image_bytes: Optional[Union[int, str]] = None
    """Maximum image size for vision-language benchmarks.
    When set, images exceeding this limit are re-encoded (JPEG compression + downscale)
    via ``compress_image_to_limit`` before base64 encoding.  ``None`` disables compression.
    Accepts an integer byte count or a human-readable string such as ``'5mb'``, ``'500kb'``,
    ``'1.5gb'`` (parsed by ``parse_size``).
    Useful for avoiding 413 errors when sending multi-image payloads to APIs."""

    evaluation_version: str = 'v1.0'
    """Published evaluation semantics version used for cache compatibility."""

    dataset_revision: Optional[str] = None
    """Optional immutable revision of the remote dataset source."""

    def __post_init__(self):
        """Validate fields after initialization."""
        from evalscope.evaluation_versioning import validate_evaluation_version

        validate_evaluation_version(self.evaluation_version)
        if self.few_shot_num < 0:
            raise ValueError('few_shot_num must be >= 0')
        self._normalize_metric_list()
        self._normalize_primary_metric()
        self._validate_primary_metric()

    def _normalize_metric_list(self) -> None:
        """Normalize unambiguous legacy scorer aliases at the adapter boundary.

        Only pure re-spellings are listed. An entry here must keep ``get_metric()`` working, since
        a declared name is looked up in the metric registry: ``acc`` and ``exact_match`` are both
        registered, and the rest name no scorer at all because their adapter computes its own
        metrics. A name whose canonical form is *not* registered while the alias is would break
        that lookup, so it must not be added.

        Aliases that reassign meaning (``total_score`` -> ``judge_score``) are deliberately absent:
        built-in adapters now emit canonical names directly, so listing them here would only hide
        the reassignment warning a third-party adapter needs to see.
        """
        aliases = {'acc', 'f1_score', 'F1', 'em'}
        normalized = []
        for entry in self.metric_list:
            raw_name = entry if isinstance(entry, str) else next(iter(entry), '')
            if raw_name not in aliases:
                normalized.append(entry)
                continue
            canonical_name = migrate_legacy_identity(raw_name, 'identity', benchmark_name=self.name).name
            if isinstance(entry, str):
                normalized.append(canonical_name)
            else:
                normalized.append({canonical_name: entry[raw_name]})
        self.metric_list = normalized

    def _normalize_primary_metric(self) -> None:
        """Normalize the common string shorthand to a selector."""
        if not isinstance(self.primary_metric, str):
            return
        identity = migrate_legacy_identity(self.primary_metric, self.aggregation, benchmark_name=self.name)
        self.primary_metric = MetricSelector(name=identity.name)

    def _metric_names(self) -> List[str]:
        """Return the distinct raw metric names declared in ``metric_list``.

        Mirrors how ``match_score()`` reads ``metric_list``: a plain string is the metric name,
        a dict maps a single metric name to its options.

        Returns:
            Distinct raw metric names, in declaration order.
        """
        names: List[str] = []
        for entry in self.metric_list or ():
            if isinstance(entry, str):
                name = entry
            elif isinstance(entry, dict) and entry:
                name = next(iter(entry))
            else:
                name = None
            if name and name not in names:
                names.append(name)
        return names

    def _validate_primary_metric(self) -> None:
        """Reject a primary metric that is not declared, and warn when one is missing.

        A benchmark reporting several metrics should say which one carries the conclusion,
        otherwise every consumer has to guess. Staying silent only warns here because this check
        runs at import time (``@register_benchmark`` constructs the meta) and third-party adapters
        may predate the selector. Report generation applies the strict rule: without a selector,
        exactly one non-diagnostic identity must remain.

        Naming a metric that is not in ``metric_list`` does raise: the field is new, so no
        existing adapter can hit it, and the value can only be a typo.

        Only the two own fields ``metric_list`` and ``primary_metric`` are read: no
        ``task_config`` access and no dataset resolution, so instantiating an adapter without a
        task config (as the docs pipeline does) stays unaffected.

        Raises:
            ValueError: If ``primary_metric`` is not part of ``metric_list``.
        """
        names = self._metric_names()

        if self.primary_metric is not None:
            canonical_names = {
                migrate_legacy_identity(name, self.aggregation, benchmark_name=self.name).name for name in names
            }
            if self.primary_metric.name not in canonical_names:
                raise ValueError(
                    f"benchmark '{self.name}': primary_metric='{self.primary_metric.name}' is not in "
                    f'metric_list {names}'
                )
            return

        if len(names) >= 2:
            logger.warning(
                f"benchmark '{self.name}': metric_list declares multiple metrics {names} but no "
                f'primary_metric; report generation will reject multiple scored identities. '
                f'Declare primary_metric to make the choice explicit.'
            )

    def _is_spec_entry(self, entry: Any) -> bool:
        """Return True if entry is a spec dict (new structured form)."""
        return isinstance(entry, dict) and ('description' in entry) and ('type' in entry) and ('value' in entry)

    def _extract_value(self, entry: Any) -> Any:
        """Extract runtime value from a spec entry or return raw value."""
        if self._is_spec_entry(entry):
            value = entry.get('value')
            if entry.get('choices') and value not in entry['choices']:
                raise ValueError(f'Value {value} not in choices {entry["choices"]} in {self.name} extra_params.')
            return value
        return entry

    def get_extra_params(self) -> Dict:
        """Get plain extra param dict, only param name and value."""
        param_dict = {}
        for key, value in self.extra_params.items():
            param_dict[key] = self._extract_value(value)
        return param_dict

    def to_dict(self) -> dict:
        """Convert to dictionary, maintaining backward compatibility."""
        result = self._serialize_models(asdict(self))
        result.pop('evaluation_version', None)
        return result

    def to_string_dict(self) -> dict:
        """Convert to string dictionary, excluding data_adapter."""
        cur_dict = copy.deepcopy(self._serialize_models(asdict(self)))
        if 'data_adapter' in cur_dict:
            del cur_dict['data_adapter']
        cur_dict.pop('evaluation_version', None)

        cur_dict['extra_params'] = self.get_extra_params()
        return cur_dict

    @classmethod
    def _serialize_models(cls, value: Any) -> Any:
        """Recursively serialize Pydantic values nested in this dataclass."""
        if isinstance(value, BaseModel):
            return value.model_dump(mode='json')
        if isinstance(value, dict):
            return {key: cls._serialize_models(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [cls._serialize_models(item) for item in value]
        return value

    def _update(self, args: dict):
        """Update instance with provided arguments, maintaining backward compatibility."""
        args = copy.deepcopy(args)

        if 'evaluation_version' in args:
            raise ValueError(
                'evaluation_version must be declared by BenchmarkMeta, not overridden through dataset_args.'
            )

        if args.get('local_path'):
            self.dataset_id = args['local_path']
            del args['local_path']

        if args.get('filters'):
            self._update_filters(args['filters'])
            del args['filters']

        if args.get('extra_params'):
            self._update_extra_params(args['extra_params'])
            del args['extra_params']

        # Update fields with validation
        for key, value in args.items():
            if hasattr(self, key):
                setattr(self, key, value)  # Validate few_shot_num if it's being updated
                if key == 'few_shot_num' and value < 0:
                    raise ValueError('few_shot_num must be >= 0')

        self._normalize_metric_list()
        self._normalize_primary_metric()
        self._validate_primary_metric()

    def _update_filters(self, new_filters: dict):
        if self.filters is None:
            self.filters = OrderedDict()
        new_filters = OrderedDict(new_filters)
        # insert filters at the beginning
        self.filters = OrderedDict(list(new_filters.items()) + list(self.filters.items()))

    def _update_extra_params(self, new_params: dict):
        for key, value in new_params.items():
            if key in self.extra_params:
                # Update only the 'value' field if it's a spec entry
                if self._is_spec_entry(self.extra_params[key]):
                    self.extra_params[key]['value'] = value
                else:
                    self.extra_params[key] = value
            else:
                raise KeyError(f'Extra param {key} not found in benchmark {self.name} extra_params.')
