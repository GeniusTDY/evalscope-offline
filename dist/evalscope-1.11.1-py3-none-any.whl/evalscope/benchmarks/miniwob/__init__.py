"""BrowserGym MiniWoB benchmark."""
